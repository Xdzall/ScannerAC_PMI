using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;
using System.IO.Ports;
using static System.Runtime.InteropServices.JavaScript.JSType;
using LossTimeComponent.Services;

namespace iniReal.Pages.CS
{
    public class IndexModel : PageModel
    {
        private readonly string? _connectionString;
        private readonly LossTimeService _lossTimeService;

        public IndexModel(IConfiguration configuration, LossTimeService lossTimeService)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection");
            _lossTimeService = lossTimeService;
        }

        string MachineCode = "MCH1-02";
        // MasterData <=> Product
        // OEESN <==> iniReal
        private static DateTime? lastSDate = null;
        private static string lastReason = null;
        public List<UserInfo> listUsers = new List<UserInfo>();
        public List<ProductInfo> listCS = new List<ProductInfo>();
        public UserInfo iniUser = new UserInfo();
        public string errorMessage = "";
        public string successMessage = "";
        public string temp = "";
        public int prodplan = 0;
        public string? prodName { get; set; }
        //private static string? RlossVal = null; // Menyimpan reason loss
        //private static DateTime? TStartLossVal = null; // Menyimpan waktu produk terakhir
        DateTime WaktuSkrg;
        DateTime WaktuLoss;
        public void OnGet()
        {
            // Retrieve error message from TempData if it exists
            if (TempData.TryGetValue("ErrorMessage", out var errorMessage))
            {
                if (errorMessage != null)
                {
                    this.errorMessage = errorMessage.ToString();
                }
            }

            try
            {
                using (SqlConnection connection = new SqlConnection(_connectionString))
                {
                    connection.Open();

                    string selectData = "SELECT * FROM Masterdata WHERE MachineCode = @MachineCode";
                    using (SqlCommand command = new SqlCommand(selectData, connection))
                    {
                        command.Parameters.AddWithValue("@MachineCode", MachineCode);
                        using (SqlDataReader dataReader = command.ExecuteReader())
                        {
                            while (dataReader.Read())
                            {
                                ProductInfo productInfo = new ProductInfo();

                                if (!dataReader.IsDBNull(0))
                                    productInfo.Product_Id = dataReader.GetString(0);

                                if (!dataReader.IsDBNull(1))
                                    productInfo.Marking = dataReader.GetString(1);

                                if (!dataReader.IsDBNull(2))
                                    productInfo.ProductName = dataReader.GetString(2);

                                if (!dataReader.IsDBNull(3))
                                    productInfo.MachineName = dataReader.GetString(3);

                                if (!dataReader.IsDBNull(4))
                                    productInfo.Description = dataReader.GetString(4);

                                if (!dataReader.IsDBNull(5))
                                    productInfo.ProdPlan = dataReader.GetInt32(5);

                                if (!dataReader.IsDBNull(6))
                                    productInfo.SUT = dataReader.GetInt32(6);

                                if (!dataReader.IsDBNull(7))
                                    productInfo.NoOfOperator = dataReader.GetInt32(7);

                                if (!dataReader.IsDBNull(8))
                                    productInfo.QtyHour = dataReader.GetInt32(8);

                                if (!dataReader.IsDBNull(9))
                                    productInfo.ProdHeadHour = dataReader.GetInt32(9);

                                if (!dataReader.IsDBNull(10))
                                    productInfo.CycleTimeVacum = dataReader.GetInt32(10);

                                if (!dataReader.IsDBNull(11))
                                    productInfo.WorkHour = dataReader.GetInt32(11);

                                listCS.Add(productInfo);
                            }
                        }
                    }

                    string selectUserQrSql = "SELECT TOP 2000 * FROM OEESN WHERE MachineCode = @MachineCode ORDER BY Date DESC";
                    //string selectUserQrSql = "SELECT * FROM OEESN WHERE MachineCode = @MachineCode ORDER BY Date DESC";
                    using (SqlCommand selectUserQrCommand = new SqlCommand(selectUserQrSql, connection))
                    {
                        selectUserQrCommand.Parameters.AddWithValue("@MachineCode", MachineCode);
                        using (SqlDataReader userQrReader = selectUserQrCommand.ExecuteReader())
                        {
                            while (userQrReader.Read())
                            {
                                UserInfo userInfo = new UserInfo();
                                userInfo.Date = userQrReader.GetDateTime(0);
                                userInfo.SDate = userQrReader.GetDateTime(1);
                                userInfo.EndDate = userQrReader.GetDateTime(2);
                                userInfo.ProductTime = userQrReader.GetDecimal(3);
                                userInfo.TotalDownTime = userQrReader.GetDecimal(4);
                                userInfo.TargetUnit = userQrReader.GetDecimal(5);
                                userInfo.GoodUnit = userQrReader.GetDecimal(6);
                                userInfo.EjectUnit = userQrReader.GetDecimal(7);
                                userInfo.TotalUnit = userQrReader.GetDecimal(8);
                                userInfo.OEE = userQrReader.GetDecimal(9);
                                userInfo.Availability = userQrReader.GetDecimal(10);
                                userInfo.Performance = userQrReader.GetDecimal(11);
                                userInfo.Quality = userQrReader.GetDecimal(12);
                                userInfo.CycleTime = userQrReader.GetInt32(13);
                                userInfo.MachineCode = userQrReader.GetString(14);
                                userInfo.Product_Id = userQrReader.GetString(15);
                                userInfo.NoOfOperator = userQrReader.GetInt32(16);
                                userInfo.P_Target = userQrReader.GetDecimal(17);
                                userInfo.P_Actual = userQrReader.GetDecimal(18);
                                userInfo.IdleTime = userQrReader.GetDecimal(19);
                                userInfo.SN_GOOD = userQrReader.GetString(20);
                                userInfo.ID = userQrReader.GetInt32(21);

                                listUsers.Add(userInfo);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception: " + ex.ToString());
            }
        }

        public bool IsSnSequential(string currentSN, string previousSN)
        {
            double currentNum = double.Parse(currentSN);
            double previousNum = double.Parse(previousSN);
            return currentNum == previousNum + 1;
        }

        public async Task<IActionResult> OnPostAsync()
        {
            // 1. Bagian validasi input awal (tetap sama)
            string serialNumInput = Request.Form["SerialNum"];
            string operatInput = Request.Form["OP"];
            string prodPlanInput = Request.Form["PP"];
            string targetUnitInput = Request.Form["TU"];
            string idleInput = Request.Form["IT"];

            if (!string.IsNullOrEmpty(serialNumInput) && serialNumInput.Contains("ERROR"))
            {
                serialNumInput = serialNumInput.Replace("ERROR", "");
            }

            if (!string.IsNullOrEmpty(serialNumInput))
            {
                int indexOfPercent = serialNumInput.IndexOf("%");
                if (indexOfPercent != -1)
                {
                    serialNumInput = serialNumInput.Substring(indexOfPercent + 1);
                }
            }

            if (serialNumInput?.Length != 10 && serialNumInput?.Length != 11 && serialNumInput?.Length != 21)
            {
                TempData["ErrorMessage"] = "Serial Number Tidak valid";
                return RedirectToPage();
            }
            iniUser.SN_GOOD = string.IsNullOrEmpty(serialNumInput) ? null : serialNumInput;
            if (string.IsNullOrEmpty(iniUser.SN_GOOD))
            {
                TempData["ErrorMessage"] = "Masukkan Serial Number";
                return RedirectToPage();
            }
            if (!int.TryParse(operatInput, out int operatValue) || operatValue == 0)
            {
                TempData["ErrorMessage"] = "Jumlah Operator Tidak Boleh Kosong";
                return RedirectToPage();
            }
            if (!int.TryParse(prodPlanInput, out int prodPlanValue) || prodPlanValue == 0)
            {
                TempData["ErrorMessage"] = "Jumlah Production Plan Tidak Boleh Kosong";
                return RedirectToPage();
            }
            if (!decimal.TryParse(targetUnitInput, out decimal targetUnitValue) || targetUnitValue < 0)
            {
                TempData["ErrorMessage"] = "SUT Negative";
                return RedirectToPage();
            }

            try
            {
                using (SqlConnection connection = new SqlConnection(_connectionString))
                {
                    await connection.OpenAsync();

                    // 2. Logika untuk mendapatkan detail produk (tetap sama)
                    string selectDataSql = @"
                SELECT TOP 1 Product_Id, MachineCode, SUT FROM Masterdata
                WHERE MachineCode = @MachineCode AND
                      (Product_Id LIKE @SerialNumPrefix7 + '%' OR
                       Product_Id LIKE @SerialNumPrefix5 + '%' OR
                       Product_Id = @SerialNumPrefix3)
                ORDER BY CASE
                    WHEN Product_Id LIKE @SerialNumPrefix7 + '%' THEN 1
                    WHEN Product_Id LIKE @SerialNumPrefix5 + '%' THEN 2
                    WHEN Product_Id = @SerialNumPrefix3 THEN 3
                    ELSE 4
                END;";

                    int SUT = 0;
                    using (SqlCommand selectDataCommand = new SqlCommand(selectDataSql, connection))
                    {
                        string serialNum = iniUser.SN_GOOD;
                        selectDataCommand.Parameters.AddWithValue("@MachineCode", MachineCode);
                        selectDataCommand.Parameters.AddWithValue("@SerialNumPrefix7", serialNum.Length >= 7 ? serialNum.Substring(0, 7) : serialNum);
                        selectDataCommand.Parameters.AddWithValue("@SerialNumPrefix5", serialNum.Length >= 5 ? serialNum.Substring(0, 5) : serialNum);
                        selectDataCommand.Parameters.AddWithValue("@SerialNumPrefix3", serialNum.Length >= 3 ? serialNum.Substring(0, 3) : serialNum);

                        using (SqlDataReader dataReader = await selectDataCommand.ExecuteReaderAsync())
                        {
                            if (await dataReader.ReadAsync())
                            {
                                iniUser.Product_Id = dataReader.GetString(0);
                                iniUser.MachineCode = dataReader.GetString(1);
                                // Ambil SUT langsung dari query ini jika tersedia
                                // SUT = dataReader.GetInt32(2); 
                            }
                        }
                    }

                    // Jika SUT tidak ada di query pertama, ambil secara terpisah
                    string selectSUTSql = "SELECT SUT FROM Masterdata WHERE Product_Id = @Product_Id;";
                    using (SqlCommand selectSUTCommand = new SqlCommand(selectSUTSql, connection))
                    {
                        selectSUTCommand.Parameters.AddWithValue("@Product_Id", iniUser.Product_Id);
                        var sutResult = await selectSUTCommand.ExecuteScalarAsync();
                        if (sutResult != null) SUT = (int)sutResult;
                    }

                    int cycleTime = (operatValue > 0) ? (SUT * 60 / operatValue) : 0;

                    // ================================================================
                    // 3. BLOK LOGIKA BARU UNTUK MENCATAT LOSSTIME OTOMATIS
                    // ================================================================
                    decimal idleValue = 0;

                    // Ambil waktu produk terakhir dari tabel OEESN
                    DateTime currentProductTime = DateTime.Now;
                    DateTime previousProductTime = currentProductTime;

                    string sql = @"
                    SELECT TOP 1 SDate 
                    FROM OEESN
                    WHERE MachineCode = @MachineCode
                    ORDER BY SDate DESC";

                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        command.Parameters.AddWithValue("@MachineCode", MachineCode);
                        var result = await command.ExecuteScalarAsync();

                        if (result != null && result != DBNull.Value)
                        {
                            previousProductTime = (DateTime)result;
                        }
                    }


                    // Hitung selisih waktu antar produk
                    TimeSpan idleDuration = currentProductTime - previousProductTime;


                    // Hanya proses losstime jika jeda kurang dari 2 jam (untuk menghindari jeda antar shift)
                    if (idleDuration.TotalHours > 0 && idleDuration.TotalHours <= 2)
                    {
                        double netDowntimeSeconds = CalculateNetDowntimeSeconds(previousProductTime, currentProductTime);
                        decimal aftTime = (decimal)(netDowntimeSeconds - (SUT * 5));

                        // ?? Tambahkan log debug di sini
                        Console.WriteLine("===== DEBUG LOSS TIME CHECK =====");
                        Console.WriteLine($"Previous Product Time : {previousProductTime:yyyy-MM-dd HH:mm:ss}");
                        Console.WriteLine($"Current Product Time  : {currentProductTime:yyyy-MM-dd HH:mm:ss}");
                        Console.WriteLine($"Idle Duration (sec)   : {idleDuration.TotalSeconds}");
                        Console.WriteLine($"Net Downtime (sec)    : {netDowntimeSeconds}");
                        Console.WriteLine($"SUT                   : {SUT}");
                        Console.WriteLine($"AftTime (sec)         : {aftTime}");
                        Console.WriteLine($"Threshold (SUT * 5)   : {SUT * 5}");
                        Console.WriteLine($"Condition Met?         {aftTime > SUT * 5}");
                        Console.WriteLine("===============================");

                        if (aftTime > 0)
                        {
                            double toleranceSeconds = SUT * 5; // batas waktu normal sebelum dianggap loss
                            double totalIdleSeconds = idleDuration.TotalSeconds;

                            // Jika selisih antar produk melebihi batas toleransi, catat loss
                            if (totalIdleSeconds > toleranceSeconds)
                            {
                                DateTime lossStartTime = previousProductTime.AddSeconds(toleranceSeconds);
                                DateTime lossEndTime = currentProductTime;
                                double actualLossSeconds = (lossEndTime - lossStartTime).TotalSeconds;

                                Console.WriteLine("===== LOSS TIME DETECTED =====");
                                Console.WriteLine($"MachineCode     : {MachineCode}");
                                Console.WriteLine($"SUT             : {SUT} detik");
                                Console.WriteLine($"Tolerance       : {toleranceSeconds} detik");
                                Console.WriteLine($"Previous Product: {previousProductTime:HH:mm:ss}");
                                Console.WriteLine($"Loss Start Time : {lossStartTime:HH:mm:ss}");
                                Console.WriteLine($"Loss End Time   : {lossEndTime:HH:mm:ss}");
                                Console.WriteLine($"Loss Duration   : {actualLossSeconds} detik");
                                Console.WriteLine("==============================");

                                await _lossTimeService.LogUnassignedLossTimeAsync(
                                    MachineCode, lossStartTime, lossEndTime, actualLossSeconds
                                );

                                idleValue = (decimal)(toleranceSeconds); // Idle = waktu normal (bukan loss)
                            }
                            else
                            {
                                Console.WriteLine($"[INFO] Idle only ({totalIdleSeconds} detik < {toleranceSeconds} detik) � tidak tercatat sebagai loss.");
                                idleValue = (decimal)(totalIdleSeconds);
                            }
                        }

                    }
                    else
                    {
                        Console.WriteLine($"[DEBUG] IdleDuration di luar batas (lebih dari 2 jam): {idleDuration.TotalHours} jam");
                    }

                    string insertUserQrSql = @"INSERT INTO OEESN (Date, SDate, EndDate, ProductTime, TotalDownTime, TargetUnit, GoodUnit, EjectUnit, TotalUnit, OEE, 
                                           Availability, Performance, Quality, CycleTime, MachineCode, Product_Id, NoOfOperator, P_Target, P_Actual, IdleTime, SN_GOOD) 
                                           VALUES (@Date, @SDate, @EndDate, @ProductTime, @TotalDownTime, @TargetUnit, @GoodUnit, @EjectUnit, (@GoodUnit + @EjectUnit), @OEE, 
                                           @Availability, @Performance, @Quality, @CycleTime, @MachineCode, @Product_Id, @NoOfOperator, @P_Target, @P_Actual, @IdleTime, @SN_GOOD);";

                    using (SqlCommand insertUserQrCommand = new SqlCommand(insertUserQrSql, connection))
                    {
                        // Bagian kalkulasi dan parameter lainnya tetap sama
                        int dataAddedToday = CountDataAddedToday(connection);
                        int ejectUnit = 0;
                        int totalUnit = dataAddedToday + ejectUnit;
                        decimal performance = (targetUnitValue > 0) ? (totalUnit / targetUnitValue) * 100 : 0;
                        decimal quality = (totalUnit > 0) ? (decimal)dataAddedToday / totalUnit * 100 : 0;
                        decimal p_actual = (cycleTime > 0) ? 3600m / (cycleTime * 1000m) : 0;

                        insertUserQrCommand.Parameters.AddWithValue("@Date", DateTime.Now);
                        insertUserQrCommand.Parameters.AddWithValue("@SDate", DateTime.Now);
                        insertUserQrCommand.Parameters.AddWithValue("@EndDate", DateTime.Now);
                        insertUserQrCommand.Parameters.AddWithValue("@ProductTime", SUT);
                        insertUserQrCommand.Parameters.AddWithValue("@TotalDownTime", 0); // Di-handle oleh service, di sini 0
                        insertUserQrCommand.Parameters.AddWithValue("@TargetUnit", targetUnitValue);
                        insertUserQrCommand.Parameters.AddWithValue("@GoodUnit", dataAddedToday);
                        insertUserQrCommand.Parameters.AddWithValue("@EjectUnit", ejectUnit);
                        insertUserQrCommand.Parameters.AddWithValue("@OEE", 0); // OEE memerlukan kalkulasi availibility yg benar
                        insertUserQrCommand.Parameters.AddWithValue("@Availability", 0); // Availibility perlu dihitung terpisah
                        insertUserQrCommand.Parameters.AddWithValue("@Performance", performance);
                        insertUserQrCommand.Parameters.AddWithValue("@Quality", quality);
                        insertUserQrCommand.Parameters.AddWithValue("@CycleTime", cycleTime);
                        insertUserQrCommand.Parameters.AddWithValue("@MachineCode", iniUser.MachineCode);
                        insertUserQrCommand.Parameters.AddWithValue("@Product_Id", iniUser.Product_Id);
                        insertUserQrCommand.Parameters.AddWithValue("@NoOfOperator", operatValue);
                        insertUserQrCommand.Parameters.AddWithValue("@P_Target", 4);
                        insertUserQrCommand.Parameters.AddWithValue("@P_Actual", p_actual);
                        insertUserQrCommand.Parameters.AddWithValue("@IdleTime", idleValue); // Menggunakan idleValue yang sudah dihitung
                        insertUserQrCommand.Parameters.AddWithValue("@SN_GOOD", iniUser.SN_GOOD);
                        // insertUserQrCommand.Parameters.AddWithValue("@ProdPlan", prodPlanValue); // Kolom ini tidak ada di tabel OEESN

                        await insertUserQrCommand.ExecuteNonQueryAsync();
                    }

                    string checkserialnum2 = @"SELECT TOP 2 SN_GOOD FROM OEESN WHERE SN_GOOD LIKE LEFT(@SN_GOOD, 5)+'%' AND MachineCode = @MachineCode ORDER BY SDate DESC;";
                    using (SqlCommand command = new SqlCommand(checkserialnum2, connection))
                    {
                        command.Parameters.AddWithValue("@sn_good", iniUser.SN_GOOD);
                        command.Parameters.AddWithValue("@MachineCode", MachineCode);
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            List<string> serialnumbers = new List<string>();
                            while (reader.Read())
                            {
                                serialnumbers.Add(reader.GetString(0));
                            }
                            if (serialnumbers.Count == 2)
                            {
                                string currentsn;
                                string previoussn;

                                if (serialnumbers[0]?.Length == 21 & serialnumbers[1]?.Length == 21)
                                {
                                    currentsn = serialnumbers[0].Substring(8);
                                    previoussn = serialnumbers[1].Substring(8);
                                }
                                else if (serialnumbers[0].Substring(0, 1).Equals('E') && serialnumbers[1].Substring(0, 1).Equals('E') || serialnumbers[0].Substring(0, 1).Equals('e') && serialnumbers[1].Substring(0, 1).Equals('e'))
                                {
                                    currentsn = serialnumbers[0].Substring(1);
                                    previoussn = serialnumbers[1].Substring(1);

                                    if (!IsSnSequential(currentsn, previoussn))
                                    {
                                        TempData["errormessage"] = "Serial Number tidak Berurutan";
                                    }
                                }
                                else
                                {
                                    currentsn = serialnumbers[0];
                                    previoussn = serialnumbers[1];
                                }

                                if (!IsSnSequential(currentsn, previoussn))
                                {
                                    TempData["errormessage"] = "Serial Number tidak Berurutan";
                                }
                            }
                        }
                    }

                    //nanti update LossTime disini
                    string dataWaktuSNTerbaru = @"SELECT TOP 2 SDate FROM OEESN WHERE SN_GOOD LIKE LEFT(@SN_GOOD, 5)+'%' AND MachineCode = @MachineCode ORDER BY SDate DESC;";
                    using (SqlCommand commandWaktuSNTerbaru = new SqlCommand(dataWaktuSNTerbaru, connection))
                    {
                        commandWaktuSNTerbaru.Parameters.AddWithValue("@SN_GOOD", iniUser.SN_GOOD);
                        commandWaktuSNTerbaru.Parameters.AddWithValue("@MachineCode", MachineCode);

                        using (SqlDataReader reader = commandWaktuSNTerbaru.ExecuteReader())
                        {
                            List<DateTime> WaktuBaru = new List<DateTime>();
                            while (reader.Read())
                            {
                                WaktuBaru.Add(reader.GetDateTime(0));
                            }
                            if (WaktuBaru.Count == 2)
                            {
                                WaktuSkrg = WaktuBaru[0];
                                WaktuLoss = WaktuBaru[1];



                            }
                        }
                    }

                }
                return RedirectToPage();
            }
            catch (SqlException ex)
            {
                // Tangkap error spesifik untuk pelanggaran UNIQUE constraint (data duplikat)
                if (ex.Number == 2627 || ex.Number == 2601)
                {
                    TempData["ErrorMessage"] = "Serial Number Sudah Ada (dicek oleh database).";
                }
                else
                {
                    // Tangani error database lainnya
                    TempData["ErrorMessage"] = "Terjadi error database: " + ex.Message;
                }
                return RedirectToPage();
            }
            catch (Exception ex)
            {
                // Tangani error umum lainnya yang mungkin terjadi
                TempData["ErrorMessage"] = "Terjadi kesalahan: " + ex.Message;
                return RedirectToPage();
            }
        }

        public int CountDataAddedToday(SqlConnection connection)
        {
            string countDataSql = "SELECT COUNT(*) FROM OEESN WHERE Date >= @Today AND MachineCode = @MachineCode";
            using (SqlCommand countDataCommand = new SqlCommand(countDataSql, connection))
            {
                countDataCommand.Parameters.AddWithValue("@Today", DateTime.Today.AddHours(7));
                countDataCommand.Parameters.AddWithValue("@MachineCode", "MCH1-02");
                return (int)countDataCommand.ExecuteScalar() + 1;
            }
        }
        //public async Task<IActionResult> OnPostSaveLossTimeAsync()
        //{

        //    string reasonInput = Request.Form["LossTimeReason"];
        //    if (string.IsNullOrEmpty(reasonInput))
        //    {
        //        ModelState.AddModelError("LossTimeReason", "Penyebab LossTime tidak boleh kosong!");
        //        return Page(); // Kembali ke halaman dengan error
        //    }

        //    try
        //    {
        //        using (SqlConnection connection = new SqlConnection(_connectionString))
        //        {
        //            await connection.OpenAsync();

        //            string getLastSDateSql = @"
        //        SELECT TOP 1 SDate FROM OEESN 
        //        WHERE MachineCode = @MachineCode 
        //        ORDER BY SDate DESC";

        //            using (SqlCommand command = new SqlCommand(getLastSDateSql, connection))
        //            {
        //                command.Parameters.AddWithValue("@MachineCode", "MCH1-02");

        //                using (SqlDataReader reader = await command.ExecuteReaderAsync())
        //                {
        //                    if (reader.Read())
        //                    {
        //                        TStartLossVal = reader.GetDateTime(0);
        //                    }
        //                }
        //            }
        //        }

        //        // Simpan reason loss
        //        RlossVal = reasonInput;

        //        // Kirim data ke View
        //        TempData["Message"] = "LossTime disimpan, menunggu produk baru...";
        //        TempData["ReasonLoss"] = RlossVal;
        //        TempData["StartTime"] = TStartLossVal;

        //        return RedirectToPage(); // Kembali ke halaman dengan ViewData
        //    }
        //    catch (Exception ex)
        //    {
        //        return BadRequest("Terjadi kesalahan: " + ex.Message);
        //    }
        //}

        // Buat method baru untuk dipanggil dari UI
        //public async Task<IActionResult> OnPostSaveReasonAsync([FromBody] LossTimeRequest request)
        //{
        //    try
        //    {
        //        (DateTime? tStartLoss, string? discardedReason) = await _lossTimeService.GetLastSDateAndReasonAsync("MCH1-02"); // MachineCode untuk CS
        //        if (tStartLoss.HasValue)
        //        {
        //            await _lossTimeService.SaveLossTimeAsync(request.LossTimeReason, "MCH1-02", tStartLoss.Value);
        //            return new OkResult();
        //        }
        //        return new BadRequestObjectResult("Could not find start time for loss.");
        //    }
        //    catch (Exception ex)
        //    {
        //        return new BadRequestObjectResult(ex.Message);
        //    }
        //}

        /// Kelas sederhana untuk menampung waktu mulai dan selesai istirahat.
        /// 

        /// Mendapatkan daftar waktu istirahat berdasarkan hari.
        private List<RestPeriod> GetRestPeriods(DateTime forDate)
        {
            var periods = new List<RestPeriod>();
            string breakColumn = (forDate.DayOfWeek == DayOfWeek.Friday) ? "breaktime2" : "breaktimee1"; // Tentukan kolom

            // 1. Tambahkan istirahat singkat yang selalu hardcode
            periods.Add(new RestPeriod { Start = new TimeSpan(9, 30, 0), End = new TimeSpan(9, 35, 0) });
            periods.Add(new RestPeriod { Start = new TimeSpan(14, 30, 0), End = new TimeSpan(14, 35, 0) });

            // 2. Baca istirahat utama (siang) dari database
            try
            {
                using (SqlConnection connection = new SqlConnection(_connectionString))
                {
                    connection.Open();
                    // Ambil baris terbaru (asumsi ada kolom ID atau timestamp untuk order by)
                    // Jika tidak ada kolom ID, sesuaikan ORDER BY dengan kolom yang relevan atau hapus ORDER BY jika hanya ada 1 baris
                    string sql = $"SELECT TOP 1 {breakColumn} FROM AdditionalBreakTimes ORDER BY ID DESC"; // Ganti ID jika perlu
                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        var result = command.ExecuteScalar();
                        if (result != null && result != DBNull.Value)
                        {
                            string mainBreakString = result.ToString(); // Contoh: "12:00-12:45" atau "11:50-13:15"

                            // Parse string waktu istirahat utama
                            string[] times = mainBreakString.Trim().Split('-');
                            if (times.Length == 2)
                            {
                                if (TimeSpan.TryParse(times[0], out TimeSpan startTime) && TimeSpan.TryParse(times[1], out TimeSpan endTime))
                                {
                                    periods.Add(new RestPeriod { Start = startTime, End = endTime });
                                }
                                else
                                {
                                    Console.WriteLine($"Format waktu istirahat utama tidak valid di database: {mainBreakString}");
                                }
                            }
                            else
                            {
                                Console.WriteLine($"Format waktu istirahat utama tidak valid di database: {mainBreakString}");
                            }
                        }
                        else
                        {
                            Console.WriteLine("Tidak ada data waktu istirahat utama ditemukan di database.");
                            // Fallback jika tidak ada data (opsional)
                            // if (forDate.DayOfWeek == DayOfWeek.Friday) { periods.Add(new RestPeriod { Start = new TimeSpan(11, 50, 0), End = new TimeSpan(13, 15, 0) }); }
                            // else { periods.Add(new RestPeriod { Start = new TimeSpan(12, 0, 0), End = new TimeSpan(12, 45, 0) }); }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error reading main break time from database: {ex.Message}");
                // Jika gagal, bisa fallback ke hardcode istirahat utama (opsional)
                // if (forDate.DayOfWeek == DayOfWeek.Friday) { periods.Add(new RestPeriod { Start = new TimeSpan(11, 50, 0), End = new TimeSpan(13, 15, 0) }); }
                // else { periods.Add(new RestPeriod { Start = new TimeSpan(12, 0, 0), End = new TimeSpan(12, 45, 0) }); }
            }


            // 3. Istirahat Shift 2 dan 3 Tetap Hardcode
            periods.Add(new RestPeriod { Start = new TimeSpan(18, 0, 0), End = new TimeSpan(18, 30, 0) });
            periods.Add(new RestPeriod { Start = new TimeSpan(21, 0, 0), End = new TimeSpan(21, 45, 0) });
            periods.Add(new RestPeriod { Start = new TimeSpan(3, 0, 0), End = new TimeSpan(3, 15, 0) });
            periods.Add(new RestPeriod { Start = new TimeSpan(5, 0, 0), End = new TimeSpan(5, 30, 0) });

            return periods;
        }

        public class RestPeriod
        {
            public TimeSpan Start { get; set; }
            public TimeSpan End { get; set; }
        }
        /// Mendapatkan daftar waktu istirahat berdasarkan hari.
        //private List<RestPeriod> GetRestPeriods(DateTime forDate)
        //{
        //    var periods = new List<RestPeriod>();

        //    // Pengecualian untuk hari Jumat
        //    if (forDate.DayOfWeek == DayOfWeek.Friday)
        //    {
        //        // Istirahat Shift 1 (Jumat)
        //        periods.Add(new RestPeriod { Start = new TimeSpan(9, 30, 0), End = new TimeSpan(9, 35, 0) });
        //        periods.Add(new RestPeriod { Start = new TimeSpan(11, 50, 0), End = new TimeSpan(13, 15, 0) });
        //        periods.Add(new RestPeriod { Start = new TimeSpan(14, 30, 0), End = new TimeSpan(14, 35, 0) });

        //        // Tambahan Istirahat Shift 2
        //        periods.Add(new RestPeriod { Start = new TimeSpan(18, 0, 0), End = new TimeSpan(18, 30, 0) });
        //        periods.Add(new RestPeriod { Start = new TimeSpan(21, 0, 0), End = new TimeSpan(21, 45, 0) });

        //        // Tambahan Istirahat Shift 3
        //        periods.Add(new RestPeriod { Start = new TimeSpan(3, 0, 0), End = new TimeSpan(3, 15, 0) });
        //        periods.Add(new RestPeriod { Start = new TimeSpan(5, 0, 0), End = new TimeSpan(5, 30, 0) });
        //    }
        //    else // Untuk hari-hari kerja lainnya
        //    {
        //        // Istirahat Shift 1 (Normal)
        //        periods.Add(new RestPeriod { Start = new TimeSpan(9, 30, 0), End = new TimeSpan(9, 35, 0) });
        //        periods.Add(new RestPeriod { Start = new TimeSpan(12, 0, 0), End = new TimeSpan(12, 45, 0) });
        //        periods.Add(new RestPeriod { Start = new TimeSpan(14, 30, 0), End = new TimeSpan(14, 35, 0) });

        //        // Tambahan Istirahat Shift 2
        //        periods.Add(new RestPeriod { Start = new TimeSpan(18, 0, 0), End = new TimeSpan(18, 30, 0) });
        //        periods.Add(new RestPeriod { Start = new TimeSpan(21, 0, 0), End = new TimeSpan(21, 45, 0) });

        //        // Tambahan Istirahat Shift 3
        //        periods.Add(new RestPeriod { Start = new TimeSpan(3, 0, 0), End = new TimeSpan(3, 15, 0) });
        //        periods.Add(new RestPeriod { Start = new TimeSpan(5, 0, 0), End = new TimeSpan(5, 30, 0) });
        //    }
        //    return periods;
        //}
        /// Menghitung durasi downtime bersih dalam detik, dengan mengabaikan waktu istirahat.
        private double CalculateNetDowntimeSeconds(DateTime startTime, DateTime endTime)
        {
            if (endTime <= startTime) return 0;

            double totalExcludedSeconds = 0;

            // Loop untuk setiap hari dalam rentang downtime (untuk menangani downtime yang melewati tengah malam)
            for (var day = startTime.Date; day <= endTime.Date; day = day.AddDays(1))
            {
                var restPeriods = GetRestPeriods(day);

                foreach (var restPeriod in restPeriods)
                {
                    DateTime restStartDateTime = day.Add(restPeriod.Start);
                    DateTime restEndDateTime = day.Add(restPeriod.End);

                    // Cari tumpang tindih (overlap) antara periode downtime dan periode istirahat
                    DateTime overlapStart = startTime > restStartDateTime ? startTime : restStartDateTime;
                    DateTime overlapEnd = endTime < restEndDateTime ? endTime : restEndDateTime;

                    if (overlapEnd > overlapStart)
                    {
                        totalExcludedSeconds += (overlapEnd - overlapStart).TotalSeconds;
                    }
                }
            }

            double grossDowntimeSeconds = (endTime - startTime).TotalSeconds;
            return grossDowntimeSeconds - totalExcludedSeconds;
        }
    }

    public class ProductInfo
    {
        public string? Product_Id { get; set; }
        public string? Marking { get; set; }
        public string? ProductName { get; set; }
        public string? MachineName { get; set; }
        public string? Description { get; set; }
        public int ProdPlan { get; set; }
        public int SUT { get; set; }
        public int NoOfOperator { get; set; }
        public int QtyHour { get; set; }
        public int ProdHeadHour { get; set; }
        public int CycleTimeVacum { get; set; }
        public int WorkHour { get; set; }
    }
    public class RestTime
    {
        public int Duration { get; set; }
        public TimeSpan StartTime { get; set; }
        public TimeSpan EndTime { get; set; }
    }
    public class UserInfo
    {
        public DateTime Date { get; set; } = DateTime.Now;
        public DateTime SDate { get; set; } = DateTime.Now;
        public DateTime EndDate { get; set; } = DateTime.Now;
        public decimal ProductTime { get; set; }
        public decimal TotalDownTime { get; set; }
        public decimal TargetUnit { get; set; }
        public decimal GoodUnit { get; set; }
        public decimal EjectUnit { get; set; }
        public decimal TotalUnit { get; set; }
        public decimal OEE { get; set; }
        public decimal Availability { get; set; }
        public decimal Performance { get; set; }
        public decimal Quality { get; set; }
        public int CycleTime { get; set; }
        public string? MachineCode { get; set; }
        public string? Product_Id { get; set; }
        public int NoOfOperator { get; set; }
        public decimal P_Target { get; set; }
        public decimal P_Actual { get; set; }
        public decimal IdleTime { get; set; }
        public string? SN_GOOD { get; set; }
        public int ID { get; set; }
    }
    public class AssyLossTime
    {

        public int ID { get; set; }
        public DateTime Date { get; set; }
        public string? MachineCode { get; set; }
        public DateTime Time { get; set; }
        public int LossTime { get; set; }
        public string? Reason { get; set; }

    }
    public class LossTimeRequest
    {
        public string LossTimeReason { get; set; }
    }

}